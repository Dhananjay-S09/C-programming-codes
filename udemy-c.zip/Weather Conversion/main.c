/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    double temp;
    printf("Enter Temperature in celcius ");
    scanf("%lf",&temp);
    temp=(temp*1.8)+32;
    printf("temp in farenheit=%lf\n", temp);

    return 0;
}