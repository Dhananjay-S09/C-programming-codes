#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num;
    scanf("%d",&num);
    printf("num is %d\n",num);
    return 0;
}     