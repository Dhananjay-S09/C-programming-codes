/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int grade1;
    int grade2;
    int grade3;
    printf("enter grade1 ");
    scanf("%d",&grade1);
    printf("enter grade2 ");
    scanf("%d",&grade2);
    printf("enter grade3 ");
    scanf("%d",&grade3);
    double result;
    result=((grade1+grade2+(double)grade3)/3);
    printf("average grade=%2lf\n",result);

    return 0;
}
