/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int grade1;
    int grade2;
    scanf("%d",&grade1);
    scanf("%d",&grade2);
    printf("Average grade=%d\n",(grade1+grade2/2));
    
    return 0;
}