//Made by Vlad. Budnitski.
//AlphaTech - Programming Course.
#include <stdio.h>

int main()
{
	double height, width;
	double perimeter;
	printf("Enter the height");
	scanf("%lf",&height);
	printf("Enter the width");
	scanf("%lf",&width);
	perimeter=2*(height+width);
	printf("The Perimeter of the rectangle is %lf\n",perimeter);
	
	return 0;
}